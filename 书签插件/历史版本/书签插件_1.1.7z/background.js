chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: "manager.html" });
  });
  