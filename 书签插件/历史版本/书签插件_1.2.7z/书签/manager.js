document.addEventListener('DOMContentLoaded', () => {
  loadBookmarks();
});

async function loadBookmarks() {
  const bookmarks = await chrome.bookmarks.getTree();
  const container = document.getElementById('bookmarkContainer');
  container.innerHTML = '';

  const topFolders = bookmarks[0].children;
  
  topFolders.forEach(folder => {
    const column = document.createElement('div');
    column.className = 'bookmark-folder';
    
    const folderTitle = document.createElement('h3');
    folderTitle.className = 'folder-title';
    folderTitle.textContent = folder.title || 'Bookmarks Bar';
    column.appendChild(folderTitle);
    
    processBookmarkNode(folder, column);
    
    container.appendChild(column);
  });
}

function processBookmarkNode(node, parentElement) {
  node.children?.forEach(child => {
    if (child.url) {
      const bookmarkElement = createBookmarkElement(child);
      parentElement.appendChild(bookmarkElement);
    } else {
      const folderDiv = document.createElement('div');
      folderDiv.className = 'subfolder';
      
      const folderTitle = document.createElement('h4');
      folderTitle.className = 'folder-title';
      folderTitle.textContent = child.title;
      folderDiv.appendChild(folderTitle);
      
      processBookmarkNode(child, folderDiv);
      
      parentElement.appendChild(folderDiv);
    }
  });
}

function createBookmarkElement(bookmark) {
  const element = document.createElement('div');
  element.className = 'bookmark-item';
  
  const favicon = document.createElement('div');
  favicon.className = 'favicon-placeholder';
  element.appendChild(favicon);
  
  const title = document.createElement('span');
  title.className = 'bookmark-title';
  title.textContent = bookmark.title || bookmark.url;
  element.appendChild(title);
  
  const actions = document.createElement('div');
  actions.className = 'bookmark-actions';
  
  const editButton = document.createElement('button');
  editButton.className = 'action-button';
  editButton.textContent = 'Edit';
  editButton.onclick = (e) => {
    e.stopPropagation();
    editBookmark(bookmark, title);
  };
  actions.appendChild(editButton);
  
  const deleteButton = document.createElement('button');
  deleteButton.className = 'action-button';
  deleteButton.textContent = 'Delete';
  deleteButton.onclick = (e) => {
    e.stopPropagation();
    deleteBookmark(bookmark.id);
  };
  actions.appendChild(deleteButton);
  
  element.appendChild(actions);
  
  element.onclick = () => {
    chrome.tabs.create({ url: bookmark.url });
  };
  
  return element;
}

function editBookmark(bookmark, titleElement) {
  const newTitle = prompt('Edit bookmark title:', bookmark.title);
  if (newTitle !== null) {
    chrome.bookmarks.update(bookmark.id, {
      title: newTitle
    }, () => {
      titleElement.textContent = newTitle;
    });
  }
}

async function deleteBookmark(id) {
  if (confirm('Are you sure you want to delete this bookmark?')) {
    await chrome.bookmarks.remove(id);
    loadBookmarks();
  }
}
