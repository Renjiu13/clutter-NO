// popup.js
window.onload = function() {
    chrome.tabs.create({ url: "manager.html" });
    window.close();
  };
  