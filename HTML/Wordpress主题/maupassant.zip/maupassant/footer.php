        </div>
    </div>
</div>
<footer id="footer" class="site-footer">
    <div class="container footer-container">
        <div class="footer-content">
            <div class="footer-copyright">
                &copy; 2025 <a href="<?php echo esc_url(home_url('/')); ?>">杂货铺</a> & <a href="https://ha.accdu.cloudns.org">阿旺</a>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
