<?php get_header(); ?>

<div class="col-8" id="main">
    <div class="res-cons">
        <div class="error-page" style="text-align: center; padding: 50px 20px; max-width: 600px; margin: 0 auto;">
            <h1 style="font-size: 120px; font-weight: 700; color: #333; margin: 0; line-height: 1.2;">404</h1>
            <div style="width: 60px; height: 3px; background: #666; margin: 20px auto;"></div>
            <h2 class="post-title" style="font-size: 24px; color: #444; margin: 20px 0;">
                <?php _e('页面未找到', 'maupassant'); ?>
            </h2>
            <p style="font-size: 16px; color: #666; margin-bottom: 30px;">
                <?php _e('抱歉，您访问的页面不存在或已被移除。', 'maupassant'); ?>
            </p>
            
            <a href="<?php echo esc_url(home_url('/')); ?>" style="display: inline-block; padding: 10px 25px; background-color: #444; color: #fff; text-decoration: none; border-radius: 4px; font-size: 16px; margin-bottom: 20px;">
                <?php _e('返回首页', 'maupassant'); ?>
            </a>
            
            <div style="max-width: 400px; margin: 0 auto;">
                <?php get_search_form(); ?>
            </div>
        </div>
    </div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>