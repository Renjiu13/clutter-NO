jQuery(document).ready(function($){
    // 检查页面是否可滚动
    function isPageScrollable() {
        var docHeight = $(document).height();
        var winHeight = $(window).height();
        return docHeight > winHeight + 10; // 添加一点余量
    }
    
    // 如果页面不可滚动，直接返回
    if (!isPageScrollable()) {
        return;
    }
    
    // 初始检查滚动位置
    if ($(window).scrollTop() > 300) {
        $(".scroll-to-top").fadeIn(800);
    } else {
        $(".scroll-to-top").fadeOut(350);
    }
    
    // 监听滚动事件
    $(window).scroll(function() {
        if ($(window).scrollTop() > 300) {
            $(".scroll-to-top").fadeIn(800);
        } else {
            $(".scroll-to-top").fadeOut(350);
        }
    });
    
    // 点击按钮回到顶部
    $(".scroll-to-top").click(function(){
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
});