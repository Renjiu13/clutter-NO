# Maupassant

A WordPress Theme ported from the Typecho Theme by Cho.

![template preview](https://ddydeg.by3302.livefilestore.com/y2p1ZgHER4eIFaEHhwaf96MvZH4_iLufEIDj7o8acDgI1GXFDtPI-eRAgvokFoR9irbz738gMmWc_N7yexG6uhB1Dcmelb0cXg8HexpiAdZ5HQ/m.png "Maupassant template preview")

### Maupassant on different platform:

+ Typecho：https://github.com/pagecho/maupassant/
+ Octopress：https://github.com/pagecho/mewpassant/
+ Farbox：https://github.com/pagecho/Maupassant-farbox/
+ Ghost: https://github.com/LjxPrime/maupassant (by LjxPrime)
+ Hexo: https://github.com/tufu9441/maupassant-hexo (by tufu9441)