=== Maupassant ===
Contributors: cho, sdg32
Tested up to: 5.6
Requires PHP: 5.6
Stable tag: 1.1
License: MIT License
License URI: https://opensource.org/licenses/MIT

== Description ==

Maupassant is a simple wordpress blog theme.
