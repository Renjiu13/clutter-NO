<?php
/*
Template Name: 文章归档
Description: 显示按年归档的文章列表
*/
get_header(); ?>

<div id="primary" class="content-area">
    <div class="container">
        <div class="row">
            <main id="main" class="site-main col-md-8">
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h1 class="entry-title"><?php the_title(); ?></h1>
                    </header>

                    <div class="entry-content">
                        <?php the_content(); ?>
                        
                        <div class="archive-content">
                            <?php
                            // 获取所有文章日期
                            $years = $wpdb->get_col("SELECT DISTINCT YEAR(post_date) FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post' ORDER BY post_date DESC");
                            
                            // 遍历每一年
                            foreach($years as $year) :
                                // 获取该年份的文章
                                $posts = $wpdb->get_results("SELECT ID, post_title, post_date FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post' AND YEAR(post_date) = '$year' ORDER BY post_date DESC");
                                
                                // 如果该年有文章才显示
                                if($posts) :
                            ?>
                                <div class="archive-year">
                                    <h2><?php echo $year; ?></h2>
                                    
                                    <ul class="archive-posts">
                                        <?php foreach($posts as $post) : ?>
                                            <li class="archive-post-item">
                                                <span class="post-date"><?php echo date_i18n('Y年m月d日', strtotime($post->post_date)); ?></span>
                                                <a href="<?php echo get_permalink($post->ID); ?>" class="post-title">
                                                    <?php echo $post->post_title; ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    </div>
                </article>
            </main>

            <div id="secondary" class="widget-area col-md-4" role="complementary">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>

<style>
.archive-year {
    margin-bottom: 30px;
}
.archive-year h2 {
    font-size: 22px;
    color: #333;
    margin-bottom: 15px;
    padding-bottom: 5px;
    border-bottom: 1px solid #ddd;
}
.archive-posts {
    list-style-type: disc;
    padding-left: 25px;
    margin-top: 10px;
}
.archive-post-item {
    margin-bottom: 12px;
    line-height: 1.5;
    display: flex;
    align-items: baseline;
}
.archive-post-item:before {
    content: none;
}
.post-date {
    color: #333;
    margin-right: 8px;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 500;
}
.post-title {
    text-decoration: none;
    color: #666;
    font-size: 15px;
}
.post-title:hover {
    color: #000;
    text-decoration: underline;
}
/* 确保内容区域有足够的高度 */
#primary {
    min-height: 80vh;
}
/* 清除浮动 */
.row:after {
    content: "";
    display: table;
    clear: both;
}
/* 修复导航栏对齐问题 */
#logo {
    display: inline-block;
    float: none;
    vertical-align: middle;
    text-decoration: none;
    color: #333;
    font-weight: bold;
    font-size: 24px;
}
@media (max-width: 768px) {
    .archive-post-item {
        flex-direction: column;
        align-items: flex-start;
    }
    .post-date {
        margin-bottom: 5px;
    }
}
</style>

<?php get_footer(); ?>
