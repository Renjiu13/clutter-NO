</div>
    </div>
</div>
<footer id="footer" class="site-footer">
    <div class="container footer-container">
        <div class="footer-content">
            <div class="footer-copyright">
                &copy; 2025 <a href="<?php echo esc_url(home_url('/')); ?>">杂货铺</a> & <a href="https://ha.accdu.cloudns.org">阿旺</a>
            </div>
        </div>
    </div>
</footer>

<!-- 回到顶部按钮 -->
<div class="scroll-to-top">回顶部</div>

<?php wp_footer(); ?>
</body>
</html>
